﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;




namespace client
{
    public partial class Form1 : Form
    {

        bool terminating = false;
        bool connected = false;
        Socket clientSocket;

        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            InitializeComponent();
        }

        private void button_connect_Click(object sender, EventArgs e)
        {
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            string IP = textBox_ip.Text;

            int portNum;
            if(Int32.TryParse(textBox_port.Text, out portNum))
            {
                try
                {
                    clientSocket.Connect(IP, portNum);
                    string username = Button_Name.Text;

                    if (username != "" && username.Length <= 64)
                    {
                        Byte[] buffer = new Byte[64];
                        buffer = Encoding.Default.GetBytes(username);
                        clientSocket.Send(buffer);

                        
                    }
                    button_connect.Enabled = false;
                    textBox_message.Enabled = true;
                    button_send.Enabled = true;
                    connected = true;
                    logs.AppendText("Connected to the server!\n");

                    Thread receiveThread = new Thread(Receive);
                    receiveThread.Start();
                    
                }
                catch
                {
                    button_connect.Enabled = true;
                    logs.AppendText("Could not connect to the server!\n");
                }
            }
            else
            {
                button_connect.Enabled = true;
                logs.AppendText("Check the port\n");
            }

        }

        private void Receive()
        {
            while(connected)
            {   
                try
                {
                    Byte[] buffer = new Byte[64];
                    clientSocket.Receive(buffer);

                    string incomingMessage = Encoding.Default.GetString(buffer);
                    incomingMessage = incomingMessage.Substring(0, incomingMessage.IndexOf("\0"));
                    if (incomingMessage == "You are not in database, disconnecting" || incomingMessage == "You are already connected")
                    {
                        connected = false;
                        button_connect.Enabled = true;
                        button_send.Enabled = false;
                        textBox_message.Enabled = false;
                    }


                    logs.AppendText(incomingMessage + "\n");
                }
                catch
                {
                    if (!terminating)
                    {
                        logs.AppendText("Disconnected from server\n");
                        button_connect.Enabled = true;
                        textBox_message.Enabled = false;
                        button_send.Enabled = false;
                    }

                    clientSocket.Close();
                    connected = false;
                    button_connect.Enabled = true;
                    button_send.Enabled = false;
                    textBox_message.Enabled = false;
                }

            }
        }

        private void Form1_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            connected = false;
            terminating = true;
            Environment.Exit(0);
        }

        private void button_send_Click(object sender, EventArgs e)
        {
            string message = textBox_message.Text;
            message = Button_Name.Text + ": " + message;
            if(message != "" && message.Length <= 64)
            {
                Byte[] buffer = new Byte[64];
                buffer = Encoding.Default.GetBytes(message);
                clientSocket.Send(buffer);
                logs.AppendText("Message sent to other clients\n");
                textBox_message.Text = "";
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_Disconnect_Click(object sender, EventArgs e)
        {               button_connect.Enabled = true;
            clientSocket.Close();
            connected = false;

        }
    }
}
