﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace server
{
    public struct socnames
    {
       public Socket socket;
       public string username;

    }
    public partial class Form1 : Form
    {

       
        Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        List<Socket> clientSockets = new List<Socket>();
        List<string> Onlines = new List<string>();
        bool terminating = false;
        bool listening = false;

        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            InitializeComponent();
        }

        private void button_listen_Click(object sender, EventArgs e)
        {
            int serverPort;

            if(Int32.TryParse(textBox_port.Text, out serverPort))
            {
                IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, serverPort);
                serverSocket.Bind(endPoint);
                serverSocket.Listen(3);

                listening = true;
                button_listen.Enabled = false;


                Thread acceptThread = new Thread(Accept);
                acceptThread.Start();

                logs.AppendText("Started listening on port: " + serverPort + "\n");

            }
            else
            {
                logs.AppendText("Please check port number \n");
            }
        }

        private void Accept()
        {
            while(listening)
            {
                try
                {
                    Socket newClient = serverSocket.Accept();
                    clientSockets.Add(newClient);
                    

                    Thread receiveThread = new Thread(Receive);
                    receiveThread.Start();
                }
                catch
                {
                    if (terminating)
                    {
                        listening = false;
                    }
                    else
                    {
                        logs.AppendText("The socket stopped working.\n");
                    }

                }
            }
        }
        string username;
        private void Receive()
        {
            socnames thisClient = new socnames();
            
            thisClient.socket = clientSockets[clientSockets.Count() - 1];
            


            bool connected = false;
            string line;
            bool indb = false;
            bool added = false;
            try
            {
                Byte[] buffer = new Byte[64];
                thisClient.socket.Receive(buffer);


                username = Encoding.Default.GetString(buffer);
                username = username.Substring(0, username.IndexOf("\0"));
                StreamReader sr = new StreamReader("user_db.txt");


                line = sr.ReadLine();
                while (line != null)
                {

                    if (line == username)
                    {
                        indb = true;
                        if (!Onlines.Contains(username))
                        {
                            added = true;
                            Onlines.Add(username);
                            thisClient.username = username;
                            connected = true;
                        }
                    }


                    line = sr.ReadLine();


                }
            }
            catch
            {
                if (!terminating)
                {

                    thisClient.socket.Close();
                    clientSockets.Remove(thisClient.socket);
                    connected = false;
                }
            }
            if (connected == false)
            {
                string disconnect = "";
                if (!indb)
                {
                    logs.AppendText(username + " is not in database, disconnecting\n");
                    disconnect = "You are not in database, disconnecting";
                }
                else if (indb && !added)
                {
                    logs.AppendText(username + " is already connected\n");
                    disconnect = "You are already connected";
                }
                Byte[] buffer = Encoding.Default.GetBytes(disconnect);
                thisClient.socket.Send(buffer);
                if (!indb)
                {

                    thisClient.socket.Close();
                    clientSockets.Remove(thisClient.socket);
                    if (Onlines.Contains(username))
                    {
                        Onlines.Remove(thisClient.username);
                    }
                }
            }
            else {
                logs.AppendText(username + " logged succesfully\n");
            
            }
            while(connected && !terminating)
            {
                try
                {
                    Byte[] buffer = new Byte[64];
                    thisClient.socket.Receive(buffer);

                    string incomingMessage = Encoding.Default.GetString(buffer);
                    incomingMessage = incomingMessage.Substring(0, incomingMessage.IndexOf("\0"));
                    logs.AppendText(incomingMessage + "\n");
                    foreach (Socket client in clientSockets)
                    {   
                        try
                        {
                            if (thisClient.socket != client)
                            {
                                client.Send(buffer);
                            }
                            }
                        catch
                        {
                            logs.AppendText("There is a problem! Check the connection...\n");
                            terminating = true;

                            textBox_port.Enabled = true;
                            button_listen.Enabled = true;
                            serverSocket.Close();
                        }
                    
                    
                    }




                }
                catch
                {
                    if(!terminating)
                    {
                        logs.AppendText(thisClient.username + " has disconnected\n");
                    }
                    if (Onlines.Contains(thisClient.username))
                    {
                        Onlines.Remove(thisClient.username);
                    }
                    thisClient.socket.Close();
                    clientSockets.Remove(thisClient.socket);
                    connected = false;
                }
            }
        }

        private void Form1_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            listening = false;
            terminating = true;
            Environment.Exit(0);
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
